<?php
    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("bd_usuarios.php");

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);


    session_start();

    $todo = paginaRegistro();

    $icono = $todo[0];
    $enlaces = $todo[1];

    $usuarios = obtenerUsuarios();
    $tam = count($usuarios);

    if (isset($_SESSION['nick'])){
        $nickUser = $_SESSION['nick'];
    }else{
        $nickUser = "Invalido";
    }

    if (isset($_SESSION['permisos'])){
        $permisos = $_SESSION['permisos'];
    }else{
        $permisos = -1;
    }

    if (isset($_SESSION['correo'])){
        $correo = $_SESSION['correo'];
    }

    echo $twig->render('listaUsuarios.html',['icono' => $icono, 'enlaces' => $enlaces, 'correo' => $correo,
    'nick' => $nickUser, 'permisos' => $permisos, 'usuarios' => $usuarios, 'tam' => $tam ]);

?>