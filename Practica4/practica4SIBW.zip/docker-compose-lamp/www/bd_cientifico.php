<?php
    ob_start();
    function obtenerFotosCientifica($mysqli , $id){

        $res = $mysqli->prepare("SELECT descripcion, ruta
            FROM imagenes 
            WHERE cientifico_id = ? 
            AND descripcion IS NOT NULL;
        ");

        $res->bind_param("i", $id);
        $res->execute();
        $resultado = $res->get_result();

        $fotos = array();
        
        if ($resultado->num_rows > 0){
            while ($row = $resultado->fetch_assoc()) {
                $auxiliar = array(
                    'descripcion' => $row['descripcion'],
                    'ruta' => $row['ruta']
                );

                array_push($fotos,$auxiliar);
            }

        } 
        else {
            $fotos = array();
        }
        

        return $fotos;

    }

    function obtenerInformacion($mysqli, $id, $conFormato){
    
        $info = array();
        
        $res = $mysqli->prepare("SELECT nombre, lugar_nacimiento, lugar_muerte, 
                                fecha_nacimiento, fecha_muerte, biografia
                                FROM cientificos
                                WHERE id = ?;");

        $res->bind_param("i", $id);
        $res->execute();
        $resultado = $res->get_result();

        if ($row = $resultado->fetch_assoc()) {

            $info = array(
                'nombre' => $row['nombre'],
                'lugar_nacimiento' =>  $row['lugar_nacimiento'],
                'lugar_muerte' =>  $row['lugar_muerte'],
                'fecha_nacimiento' =>  $row['fecha_nacimiento'],
                'fecha_muerte' => $row['fecha_muerte'],
                'biografia' => $row['biografia']
            );

            

            //poner la fecha en el formato elegido
            if ($conFormato){
                if ($id != 5) {
                    $fechas = formatoFecha($info['fecha_nacimiento'],$info['fecha_muerte']);
                    if ($info['fecha_nacimiento'] != null)
                        $info['fecha_nacimiento'] = $fechas[0];
                    
                    if($info['fecha_muerte'] != null){
                        $info['fecha_muerte'] = $fechas[1];
                    }
                    

                } else {
                    //fecha antes de cristo
                    $info['fecha_nacimiento'] = date(' Y \A\C', strtotime($info['fecha_nacimiento']));
                    $info['fecha_muerte'] = date('F \d\e Y \A\C', strtotime($info['fecha_muerte']));
                }
            }

            //interpreta los espacios como etiquetas <br>
            $info['biografia'] = nl2br($info['biografia']);

        } else {
            $info = array(
                'nombre' => "no encontrado",
                'lugar_nacimiento' => "no encontrado",
                'lugar_muerte' => "no encontrado",
                'fecha_nacimiento' => "no encontrado",
                'fecha_muerte' => "no encontrado",
                'biografia' => "no encontrado"
            );
        }

        return $info;
    }

    function obtenerEnlacesCientifica($mysqli, $id){

        $res = $mysqli->prepare("SELECT descripcion, url FROM enlaces WHERE id_cientifico = ?;");
        $res->bind_param("i", $id);
        $res->execute();
        $resultado = $res->get_result();

        $enlaces = array();

        if ($resultado->num_rows > 0){
            while ($row = $resultado->fetch_assoc()) {
                $auxiliar = array(
                    'descripcion' => $row['descripcion'],
                    'url' => $row['url']
                );
                array_push($enlaces,$auxiliar);
            }
        }
           
        return $enlaces;
    }

    function obtenerBotones($mysqli , $id){

        $res = $mysqli->query("SELECT ruta , descripcion 
                               FROM imagenes 
                               WHERE tipo = 'png';");
        
        $botones = array();

        if ($res->num_rows > 0){
            while ($row = $res->fetch_assoc()) {
                $auxiliar = array(
                    'descripcion' => $row['descripcion'],
                    'ruta' => $row['ruta']
                );
                array_push($botones,$auxiliar);
            }
        }

        //para el enlace de impresion
        $botones[4]['descripcion'] = $botones[4]['descripcion']. "?ev=" . $id;

        return $botones;
    }

    function obtenerComentarios($mysqli, $id){

        $res = $mysqli->prepare("SELECT nombre , correo, fecha, comentario, editado
                               FROM comentarios
                               WHERE id_cientifico = ?;");
        
        $res->bind_param("i", $id);
        $res->execute();

        $resultado = $res->get_result();

        $comentarios = array();

        if ($resultado->num_rows > 0){
            
            while ($row = $resultado->fetch_assoc()) {
                $auxiliar = array(
                    'nombre' => $row['nombre'],
                    'correo' => $row['correo'],
                    'fecha' => $row['fecha'],
                    'comentario' => $row['comentario'],
                    'editado' => $row['editado']
                );
                array_push($comentarios,$auxiliar);
            }
        }

        return $comentarios;
    }

    function formatoFecha($fecha_nacimiento, $fecha_muerte){
        // Array con los nombres de los meses en español
        $meses_espanol = array('Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre');

        $fechas = array();

        $fecha_nacimiento_timestamp = strtotime($fecha_nacimiento);
        $dia = date('d', $fecha_nacimiento_timestamp);
        $mes_numero = date('n', $fecha_nacimiento_timestamp);
        $mes_nombre = $meses_espanol[$mes_numero - 1];
        $ano = date('Y', $fecha_nacimiento_timestamp);

        array_push($fechas,"$dia de $mes_nombre de $ano");

        $fecha_muerte_timestamp = strtotime($fecha_muerte);
        $dia = date('d', $fecha_muerte_timestamp);
        $mes_numero = date('n', $fecha_muerte_timestamp);
        $mes_nombre = $meses_espanol[$mes_numero - 1];
        $ano = date('Y', $fecha_muerte_timestamp);
        
        array_push($fechas,"$dia de $mes_nombre de $ano");
        
        return $fechas;
    }


    function obtenerComentario($posComentario, $idCientifico){
        $mysqli = conectar();

        $offset = $posComentario - 1;
        $res = $mysqli->prepare("SELECT id, nombre , correo, comentario 
                               FROM comentarios
                               WHERE id_cientifico = ? LIMIT 1 OFFSET ?;");
        
        $res->bind_param("ii", $idCientifico, $offset);
        $res->execute();

        $resultado = $res->get_result();

        $comentario = array(
            'id' => "no encontrado",
            'nombre' => "no encontrado",
            'correo' => "no encontrado",
            'texto' =>  "no encontrado");

        if ($row = $resultado->fetch_assoc()) {

            $comentario = array(
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'correo' =>  $row['correo'],
                'texto' =>  $row['comentario'],
            );
        }

        mysqli_close($mysqli);

        return $comentario;

    }

    function editarComentario($idComentario, $textoComentario){
        $mysqli = conectar();

        $res = $mysqli->prepare("UPDATE comentarios SET comentario = ?, editado = 1 WHERE id = ?");

        $res->bind_param("si", $textoComentario, $idComentario );
        $res->execute();

        mysqli_close($mysqli);

        if ($res->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function aniadirFotoSinId($biografia,$ruta){
        $mysqli = conectar();

        $res = $mysqli->prepare("SELECT id FROM cientificos WHERE biografia = ?;");

        $res->bind_param("s", $biografia );
        $res->execute();
        $resultado = $res->get_result();

        $id = -1;
        
        if ($row = $resultado->fetch_assoc()) {
                $id = $row['id'];
        }

        if ($id > -1){
            $res = $mysqli->prepare("INSERT INTO imagenes (cientifico_id,ruta) VALUES ( ?, ?)");

            $res->bind_param("is", $id, $ruta );
            $res->execute();

            mysqli_close($mysqli);

            if ($res->affected_rows > 0) {
                return true;
            } else {
                return false;
            }
        }
        
        mysqli_close($mysqli);
    }

    function editarCientifico($idCientifico,$nombre,$fechaNacimiento,$fechaFallecimiento,$lugarNacimiento,$lugarFallecimiento,$biografia){
        $mysqli = conectar();

        if ($fechaNacimiento == '')
            $fechaNacimiento = null;

        if ($fechaFallecimiento == '')
            $fechaFallecimiento = null;

        $res = $mysqli->prepare("UPDATE cientificos SET nombre = ?, fecha_nacimiento = ?, fecha_muerte = ?, 
        lugar_nacimiento = ?, lugar_muerte = ?, biografia = ? WHERE id = ?");

        $res->bind_param("ssssssi", $nombre,$fechaNacimiento,$fechaFallecimiento,$lugarNacimiento,$lugarFallecimiento,$biografia, $idCientifico);
        $res->execute();

        //mysqli_close($mysqli);

        if ($res->affected_rows > 0) {
            return true;
        } else {
            var_dump($res->error);
            return false;
        }   
    }

    function aniadirFotoCientifica($idCientifico, $ruta, $descripcion){
        $mysqli = conectar();

        $res = $mysqli->prepare("INSERT INTO imagenes (cientifico_id, descripcion, ruta) VALUES (?, ?, ?)");

        $res->bind_param("iss", $idCientifico, $descripcion, $ruta);
        $res->execute();

        mysqli_close($mysqli);

        if ($res->affected_rows > 0) {
            return true;
        } else {
            return false;
        } 
    }

    function obtenerCientificos($mysqli){

        $res = $mysqli->prepare("SELECT * FROM cientificos");
        
        $res->execute();

        $resultado = $res->get_result();

        $cientificos = array();

        while ($row = $resultado->fetch_assoc()) {
            $auxiliar = array(
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'lugar_nacimiento' =>  $row['lugar_nacimiento'],
                'lugar_muerte' =>  $row['lugar_muerte'],
                'fecha_nacimiento' =>  $row['fecha_nacimiento'],
                'fecha_muerte' => $row['fecha_muerte'],
                'biografia' => $row['biografia']
            );
            

            if ($auxiliar['id'] != 5) {
                $fechas = formatoFecha($auxiliar['fecha_nacimiento'],$auxiliar['fecha_muerte']);

                if ( $auxiliar['fecha_nacimiento'] != null)
                    $auxiliar['fecha_nacimiento'] = $fechas[0];
                  
                if ( $auxiliar['fecha_muerte'] != null)
                    $auxiliar['fecha_muerte'] = $fechas[1];

            } else {
                //fecha antes de cristo
                $auxiliar['fecha_nacimiento'] = "355 AC";
                $auxiliar['fecha_muerte'] = "Marzo de 415 AC";
            }

            array_push($cientificos,$auxiliar);
        }

        return $cientificos;
    }

    function eliminarImagen($idCientifico, $descripcion){
        $mysqli = conectar();

        $res = $mysqli->prepare("DELETE FROM imagenes WHERE cientifico_id = ? AND descripcion = ?");

        $res->bind_param("is", $idCientifico, $descripcion);
        $res->execute();

        mysqli_close($mysqli);

        if ($res->affected_rows > 0) {
            return true;
        } else {
            return false;
        } 
    }

    function editarImagen($idCientifico, $descripcion, $ruta){
        $mysqli = conectar();

        $res = $mysqli->prepare("UPDATE imagenes SET descripcion = ? 
        WHERE ruta = ? AND cientifico_id = ?");

        $res->bind_param("ssi", $descripcion, $ruta, $idCientifico);
        $res->execute();

        mysqli_close($mysqli);

        if ($res->affected_rows > 0) {
            return true;
        } else {
            return false;
        } 
    }

    function obtenerHashtags($mysqli, $idCientifica){
        
        $res = $mysqli->prepare("SELECT nombre FROM hashtags WHERE id_cientifico = ?;");

        $res->bind_param("i", $idCientifica);
        $res->execute();
        $resultado = $res->get_result();

        $hashtags = array();

        while ($row = $resultado->fetch_assoc()) {
            array_push($hashtags, $row['nombre']);
        } 

        return $hashtags;
    }

    function aniadirHashtag($idCientifico, $hashtag){
        $mysqli = conectar();

        $res = $mysqli->prepare("INSERT INTO hashtags (id_cientifico, nombre) VALUES (?, ?)");

        $res->bind_param("is", $idCientifico, $hashtag);
        $res->execute();

        mysqli_close($mysqli);

        if ($res->affected_rows > 0) {
            return true;
        } else {
            return false;
        } 
    }

    function buscarCientifico($mysqli,$nombre, $biografia){

        $nombre = '%' . $nombre . '%';
        $biografia = '%' . $biografia . '%';

        if ($nombre != "" && $biografia != ""){
            $res = $mysqli->prepare("SELECT * FROM cientificos WHERE nombre LIKE ? AND biografia LIKE ?;");

            $res->bind_param("ss", $nombre, $biografia);

        }else if ($nombre != ""){
            $res = $mysqli->prepare("SELECT * FROM cientificos WHERE nombre LIKE ?;");

            $res->bind_param("s", $nombre);

        }else {
            $res = $mysqli->prepare("SELECT * FROM cientificos WHERE biografia LIKE ?;");

            $res->bind_param("s", $biografia);
        }
        
        $res->execute();
        $resultado = $res->get_result();

        $cientificos = array();

        while ($row = $resultado->fetch_assoc()) {
            $auxiliar = array(
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'lugar_nacimiento' =>  $row['lugar_nacimiento'],
                'lugar_muerte' =>  $row['lugar_muerte'],
                'fecha_nacimiento' =>  $row['fecha_nacimiento'],
                'fecha_muerte' => $row['fecha_muerte'],
                'biografia' => $row['biografia']
            );
            

            if ($auxiliar['id'] != 5) {
                $fechas = formatoFecha($auxiliar['fecha_nacimiento'],$auxiliar['fecha_muerte']);

                if ( $auxiliar['fecha_nacimiento'] != null)
                    $auxiliar['fecha_nacimiento'] = $fechas[0];
                  
                if ( $auxiliar['fecha_muerte'] != null)
                    $auxiliar['fecha_muerte'] = $fechas[1];

            } else {
                //fecha antes de cristo
                $auxiliar['fecha_nacimiento'] = "355 AC";
                $auxiliar['fecha_muerte'] = "Marzo de 415 AC";
            }

            array_push($cientificos,$auxiliar);
        } 

        return $cientificos;
    }

    
    
?> 