<?php
    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("bd_usuarios.php");

    if ($_GET['accion'] == 'obtenerArray') {
        $mysqli = conectar();

        $palabras = obtenerPalabras($mysqli);

        mysqli_close($mysqli);

        echo json_encode($palabras);
    }
    else if ($_GET['accion'] == 'obtenerSesion'){
        session_start();

        $sessionData = array(
            'nick' => $_SESSION['nick'],
            'correo' => $_SESSION['correo']
        ); //tener los valores en el js

        echo json_encode($sessionData);
    }
    else if ($_GET['accion'] == 'borrarComentario') {
        $datosComentario = json_decode(file_get_contents('php://input'), true);
            
        $nombre = $datosComentario['nombre'];
        $fecha = $datosComentario['fecha'];
        $idCientifico = $datosComentario['idCientifico'];

        $mysqli = conectar();

        // Preparar la consulta SQL
        $sql = "DELETE FROM comentarios WHERE nombre = '$nombre' AND fecha = '$fecha' AND id_cientifico = '$idCientifico' ";

        // Ejecutar la consulta SQL
        mysqli_query($mysqli, $sql);

        // Crear un array asociativo con la respuesta
        $respuesta = array(
            'nombre' => $nombre,
            'fecha' => $fecha,
            'comentario' => $comentario
        );

        // Convertir el array a formato JSON
        $respuesta_json = json_encode($respuesta);

        // Establecer el tipo de contenido de la respuesta como JSON
        header('Content-Type: application/json');

        // Enviar la respuesta JSON
        echo $respuesta_json;

        mysqli_close($mysqli);
    }
    else{
        $nombre = $_POST["nick"];
        $correo = $_POST["correo"];
        $comentario = $_POST["comentario"];
        $fecha = $_POST["fechaYHora"];
        $idCientifico = $_POST["idCientifico"];

        $mysqli = conectar();

        // Preparar la consulta SQL
        $sql = "INSERT INTO comentarios (nombre, correo, comentario, fecha, id_cientifico, editado) 
                VALUES ('$nombre', '$correo', '$comentario', '$fecha', '$idCientifico', 0)";

        // Ejecutar la consulta SQL
        mysqli_query($mysqli, $sql);

        // Crear un array asociativo con la respuesta
        $respuesta = array(
            'nombre' => $nombre,
            'fecha' => $fecha,
            'comentario' => $comentario
        );

        // Convertir el array a formato JSON
        $respuesta_json = json_encode($respuesta);

        // Establecer el tipo de contenido de la respuesta como JSON
        header('Content-Type: application/json');

        // Enviar la respuesta JSON
        echo $respuesta_json;

        mysqli_close($mysqli);
    }

    function obtenerPalabras($mysqli){

        $res = $mysqli->query("SELECT palabra
                                FROM censuradas
                            ");

        $palabras = array();

        if ($res->num_rows > 0){
            while ($row = $res->fetch_assoc()) {
                $auxiliar = array( 'palabra' => $row['palabra']);

                array_push($palabras,$auxiliar);
            }
        }

        return $palabras;
    }

?>