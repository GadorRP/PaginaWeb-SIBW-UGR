<?php
    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("bd_usuarios.php");

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);

    session_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nombre = $_POST['lineaNombre'];
        $biografia = $_POST['lineaBiografia'];

        $todo = paginaListaCientificos($nombre,$biografia);
    }else{
        $busqueda = false;
        $todo = paginaListaCientificos($busqueda, false);
    }

    $icono = $todo[0];
    $enlaces = $todo[1];
    $cientificos = $todo[2];

    $numCientificos = count($cientificos) - 1;

    if (isset($_SESSION['nick'])){
        $nickUser = $_SESSION['nick'];
    }else{
        $nickUser = "Invalido";
    }

    if (isset($_SESSION['permisos'])){
        $permisos = $_SESSION['permisos'];
    }else{
        $permisos = -1;
    }

    echo $twig->render('listaCientificos.html',['icono' => $icono, 'enlaces' => $enlaces,
    'nick' => $nickUser, 'permisos' => $permisos, 'cientificos' => $cientificos, 'numCientificos' => $numCientificos ]);

?>