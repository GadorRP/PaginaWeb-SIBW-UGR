<?php
    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("bd_usuarios.php");

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        session_start();

        $correo = $_GET['correo'];
        $esSuper = $_GET['esSuper'];
        $permisosNuevos = $_POST['selector'];

        if ($permisosNuevos != "NoCambio"){
            if ( $esSuper != "superUsuario" || ($esSuper == "superusuario" && comprobarSuperUsuario())){
                if (editarPermisos($correo, $permisosNuevos))
                    header("Location: listaUsuarios.php");
            }else
                header("Location: index.php");
        }

        header("Location: listaUsuarios.php");
    }

    session_start();

    $correoUsuario = $_GET['id'];

    $datosUsuario = obtenerUsuario($correoUsuario);

    if ($datosUsuario['permisos'] == 0){
        $datosUsuario['permisos'] = "registrado";
    }
    else if ($datosUsuario['permisos'] == 1){
        $datosUsuario['permisos'] = "moderador";
    }
    else if ($datosUsuario['permisos'] == 2){
        $datosUsuario['permisos'] = "gestor";
    }
    else if ($datosUsuario['permisos'] == 3){
        $datosUsuario['permisos'] = "superUsuario";
    }

    $todo = paginaRegistro();
    $icono = $todo[0];
    $enlaces = $todo[1];

    $nickUser = "Invalido";

    if (isset($_SESSION['nick'])){
        $nickUser = $_SESSION['nick'];
    }

    if (isset($_SESSION['permisos'])){
        $permisos = $_SESSION['permisos'];
    }else{
        $permisos = -1;
    }



    echo $twig->render('cambiarPermisos.html',['icono' => $icono, 'enlaces' => $enlaces, 'nick' => $nickUser,
     'usuario' => $datosUsuario, 'permisos' => $permisos ]);
?>