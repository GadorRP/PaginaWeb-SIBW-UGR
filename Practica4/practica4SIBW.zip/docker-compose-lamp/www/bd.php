<?php
    include("bd_cientifico.php");

    function conectar(){
        $mysqli = new mysqli("database" , "cientifico" , "paginaWeb" , "SIBW" );

        if ($mysqli->connect_errno) {
            echo("Fallo al conectar: ". $mysqli->connect_error);
        }

        return $mysqli;
    }

    function obtenerIcono($mysqli){

        $res = $mysqli->query("SELECT ruta
                                FROM imagenes 
                                WHERE descripcion = 'icono' ");

        
        if ($res->num_rows > 0){
            $row = $res->fetch_assoc();
            
            $ruta = $row['ruta'];
        }
        
        return $ruta;
    }

    function obtenerFotos($mysqli){

        $res = $mysqli->query("SELECT  i.ruta
                                FROM imagenes i
                                INNER JOIN cientificos c ON i.cientifico_id = c.id
                                WHERE i.id IN (
                                    SELECT MIN(id)
                                    FROM imagenes
                                    GROUP BY cientifico_id
                                )");

        $fotos = array();
        
        if ($res->num_rows > 0){
            
            while ($row = $res->fetch_assoc()) {
                $auxiliar = array(
                    'ruta' => $row['ruta']
                );
                array_push($fotos,$auxiliar);
            }
        }

        return $fotos;
    }

    function obtenerNombres($mysqli){

        $res = $mysqli->query("SELECT id, nombre FROM cientificos;");

        $nombres = array();

        if ($res->num_rows > 0){

            while ($row = $res->fetch_assoc()) {
                $auxiliar = array(
                    'id' => strval($row['id']),
                    'nombre' => $row['nombre']
                );
                array_push($nombres,$auxiliar);
            }

        }else {
            $nombres = array('nombre' => 'No disponible', 'id' => 'No disponible');
        }

        return $nombres;
    }

    function obtenerEnlaces($mysqli){

        $res = $mysqli->query("SELECT descripcion, url FROM enlaces WHERE id_cientifico IS NULL; ");

        $enlaces = array();

        if ($res->num_rows > 0){
            
            while ($row = $res->fetch_assoc()) {
                $enlace = array(
                    'descripcion' => $row['descripcion'],
                    'url' => $row['url']
                );
                array_push($enlaces,$enlace);
        };

        return $enlaces;
    }
}
    function aniadirCientifica($nombre,$fechaNacimiento,$fechaFallecimiento,$lugarNacimiento,$lugarFallecimiento,$biografia){
        $mysqli = conectar();

        $res = $mysqli->prepare("INSERT INTO cientificos (nombre, fecha_nacimiento, fecha_muerte, 
        lugar_nacimiento, lugar_muerte, biografia) VALUES (?, ?, ?, ?, ?, ?)");

        
        $res->bind_param("ssssss", $nombre,$fechaNacimiento,$fechaFallecimiento,$lugarNacimiento,$lugarFallecimiento,$biografia);
        $res->execute();

        mysqli_close($mysqli);

        if ($res->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
        
    }

    function borrarCientifica($idCientifico){
        $mysqli = conectar();

        $res = $mysqli->prepare("DELETE FROM cientificos WHERE id = ?");

        $res->bind_param("i", $idCientifico);
        $res->execute();

        mysqli_close($mysqli);

        if ($res->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    function paginaPrincipal() {

        $mysqli = conectar();
        $final = array();

        //ICONO 
        $icono = obtenerIcono($mysqli);
        array_push($final,$icono);

        //FOTOS
        $fotos = obtenerFotos($mysqli);
        array_push($final,$fotos);

        //NOMBRES
        $nombres = obtenerNombres($mysqli);
        array_push($final,$nombres);

        //ENLACES
        $enlaces = obtenerEnlaces($mysqli);
        array_push($final,$enlaces);
       
        mysqli_close($mysqli);

        return $final;
    }

    

    function paginaCientifica($id) {

        $mysqli = conectar();
        $final = array();

        //ICONO 
        $icono = obtenerIcono($mysqli);
        array_push($final,$icono);

        //FOTOS CIENTIFICA
        $fotos = obtenerFotosCientifica($mysqli, $id);
        array_push($final,$fotos);

        //INFORMACION
        $info = obtenerInformacion($mysqli, $id, true);
        array_push($final,$info);

        //ENLACES CIENTIFICA
        $enlacesCientifica = obtenerEnlacesCientifica($mysqli, $id);
        array_push($final,$enlacesCientifica);

        //ENLACES AUXILIARES
        $enlacesAuxiliares = obtenerEnlaces($mysqli);
        array_push($final,$enlacesAuxiliares);
       
        //BOTONES
        $botones = obtenerBotones($mysqli, $id);
        array_push($final,$botones);

        //COMENTARIOS
        $comentarios = obtenerComentarios($mysqli, $id);
        array_push($final,$comentarios);

        //HASHTAGS
        $hashtags = obtenerHashtags($mysqli, $id);
        array_push($final,$hashtags);
       
        mysqli_close($mysqli);

        return $final;
    }

    function paginaRegistro() {

        $mysqli = conectar();
        $final = array();

        //ICONO 
        $icono = obtenerIcono($mysqli);
        array_push($final,$icono);

        //ENLACES
        $enlaces = obtenerEnlaces($mysqli);
        array_push($final,$enlaces);
       
        mysqli_close($mysqli);

        return $final;
    }

    function paginaEdicionCientifico($id){
        $mysqli = conectar();
        $final = array();

        //ICONO 
        $icono = obtenerIcono($mysqli);
        array_push($final,$icono);

        //ENLACES
        $enlaces = obtenerEnlaces($mysqli);
        array_push($final,$enlaces);

        $infoCientifica = obtenerInformacion($mysqli,$id, false);
        array_push($final,$infoCientifica);

        $fotosCientifica = obtenerFotosCientifica($mysqli,$id);
        array_push($final,$fotosCientifica);

        $enlacesCientifica = obtenerEnlacesCientifica($mysqli,$id);
        array_push($final,$enlacesCientifica);
       
        $hashtags = obtenerHashtags($mysqli, $id);
        array_push($final,$hashtags);
        
        mysqli_close($mysqli);

        return $final;
    }

    function paginaListaCientificos($nombre, $biografia){
        $mysqli = conectar();
        $final = array();

        //ICONO 
        $icono = obtenerIcono($mysqli);
        array_push($final,$icono);

        //ENLACES
        $enlaces = obtenerEnlaces($mysqli);
        array_push($final,$enlaces);

        if (!$nombre && ! $biografia)
            $infoCientificos = obtenerCientificos($mysqli);
        else
            $infoCientificos = buscarCientifico($mysqli,$nombre, $biografia);
            
        array_push($final,$infoCientificos);
       
        mysqli_close($mysqli);

        return $final;
    }
?>