<?php

    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("bd.php");

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        session_start();

        $idCientifico = $_GET['id'];
        
        $nombre = $_POST['lineaNombre'];
        $fechaNacimiento = $_POST['lineaFechaNacimiento'];
        $fechaFallecimiento = $_POST['lineaFechaFallecimiento'];
        $lugarNacimiento = $_POST['lineaLugarNacimiento'];
        $lugarFallecimiento = $_POST['lineaLugarFallecimiento'];
        $biografia = $_POST['lineaBiografia']; 
        $biografiaLimpia = strip_tags($biografia);      

        $ruta = $_POST['lineaRuta'];
        $descripcion = $_POST['lineaDescripcion'];
      
        if( $ruta != ""){
            if (!aniadirFotoCientifica($idCientifico,$ruta,$descripcion)){
                header("Location: index.php");
            }
        }

        $hashtag = $_POST['lineaHastag'];
        if( $hashtag != ""){
            if (!aniadirHashtag($idCientifico,$hashtag)){
                header("Location: index.php");
            }
        }

        $numFotos = $_GET['num'];
        for ($i = 0; $i <= $numFotos; $i++) {
            $rutaImagen = $_POST['lineaRuta' . $i];
            $descripcionImagen = $_POST['lineaDescripcion' . $i];

            if ($rutaImagen == ""){
                eliminarImagen($idCientifico,$descripcionImagen);
            }else {
                editarImagen($idCientifico,$descripcionImagen,$rutaImagen);
            }
        }
        
        
        if (editarCientifico($idCientifico,$nombre,$fechaNacimiento,$fechaFallecimiento,$lugarNacimiento,$lugarFallecimiento,$biografiaLimpia)){
            header("Location: cientifico.php?ev=$idCientifico");
        }else{
            header("Location: index.php");
        }

    }
    session_start();

    $id = $_GET['ev'];

    $todo = paginaEdicionCientifico($id);

    $icono = $todo[0];
    $enlacesAuxiliares = $todo[1];
    $info = $todo[2];
    $fotos = $todo[3];
    $enlacesCientifica = $todo[4];
    $hashtags = $todo[5];

    $numEnlaces = count($enlacesCientifica) - 1;
    $numFotos = count($fotos) - 1;
    $numHashtags = count($hashtags) - 1;
    

    $nickUser = "Invalido";
    $permisos = -1;

    if (isset($_SESSION['nick'])){
        $nickUser = $_SESSION['nick'];
    }

    if (isset($_SESSION['permisos'])){
        $permisos = $_SESSION['permisos'];
    }else{
        $permisos = -1;
    }

    echo $twig->render('editarCientifico.html',['fotos' => $fotos, 'numFotos' => $numFotos,'info' => $info,
    'id' => $id, 'enlacesCientifica' => $enlacesCientifica, 'numEnlaces' => $numEnlaces, 'enlaces' => $enlacesAuxiliares, 
    'icono' => $icono,'nick' => $nickUser, 'permisos' => $permisos, 'hashtags' => $hashtags, 'numHashtags' => $numHashtags]);
