<?php
    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("bd_usuarios.php");

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);


    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nombre = $_POST['lineaNombreCientifica'];
        $fechaNacimiento = $_POST['lineaFechaNacimiento'];
        $fechaFallecimiento = $_POST['lineaFechaFallecimiento'];
        $lugarNacimiento = $_POST['lineaLugarNacimiento'];
        $lugarFallecimiento = $_POST['lineaLugarFallecimiento'];
        $biografia = $_POST['lineaBiografia'];       
        $ruta = $_POST['lineaFoto']; 

        if (aniadirCientifica($nombre,$fechaNacimiento,$fechaFallecimiento,$lugarNacimiento,$lugarFallecimiento,$biografia)){
            if (aniadirFotoSinId($biografia, $ruta))
                header('Location: index.php');
        }
        else {
            //header('Location: inicioSesion.php');
        }

    }

    session_start();

    $todo = paginaRegistro();

    $nickUser = "Invalido";

    if (isset($_SESSION['nick'])){
        $nickUser = $_SESSION['nick'];
    }

    if (isset($_SESSION['permisos'])){
        $permisos = $_SESSION['permisos'];
    }else{
        $permisos = -1;
    }

    $icono = $todo[0];
    $enlaces = $todo[1];

    echo $twig->render('aniadirCientifico.html',['icono' => $icono, 'enlaces' => $enlaces,
     'nick' => $nickUser, 'permisos' => $permisos ]);
?>