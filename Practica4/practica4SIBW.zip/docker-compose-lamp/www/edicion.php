<?php
    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("bd_usuarios.php");

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        session_start();

        $idCientifico = $_GET['idC'];
        $idComentario = $_GET['id'];

        $comentarioEditado = $_POST['lineaTexto'];

        if (editarComentario($idComentario, $comentarioEditado))
            header("Location: cientifico.php?ev=$idCientifico");
        else
            header("Location: inicio.php");
    }

    session_start();

    $idCientifico = $_GET['idC'];
    $idComentario = $_GET['id'];

    $comentario = obtenerComentario($idComentario, $idCientifico);

    $todo = paginaRegistro();

    $nickUser = "Invalido";

    if (isset($_SESSION['nick'])){
        $nickUser = $_SESSION['nick'];
    }

    if (isset($_SESSION['permisos'])){
        $permisos = $_SESSION['permisos'];
    }else{
        $permisos = -1;
    }

    $icono = $todo[0];
    $enlaces = $todo[1];

    echo $twig->render('edicion.html',['icono' => $icono, 'enlaces' => $enlaces, 'nick' => $nickUser,
     'comentario' => $comentario, 'idCientifico' => $idCientifico, 'permisos' => $permisos ]);
?>